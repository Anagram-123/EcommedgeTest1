Rails.application.config.assets.precompile += %w(admin/* credit_cards/credit_card.gif)
