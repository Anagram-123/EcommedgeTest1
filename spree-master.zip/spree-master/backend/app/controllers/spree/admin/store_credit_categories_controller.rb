module Spree
  module Admin
    class StoreCreditCategoriesController < ResourceController
    end
  end
end
