module Spree
  module Admin
    class RefundReasonsController < ResourceController
    end
  end
end
