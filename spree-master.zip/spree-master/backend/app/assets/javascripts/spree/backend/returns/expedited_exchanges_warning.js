$(function () {
  $(document).on('change', '.return-items-table .return-item-exchange-selection', function () {
    $('.expedited-exchanges-warning').fadeIn()
  })
})
