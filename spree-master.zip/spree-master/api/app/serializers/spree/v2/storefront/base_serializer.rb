module Spree
  module V2
    module Storefront
      class BaseSerializer
        include FastJsonapi::ObjectSerializer
      end
    end
  end
end
