## 4.2.0 (unreleased)

https://guides.spreecommerce.org/release_notes/4_2_0.html

## 4.1.0 (2020-02-28)

https://guides.spreecommerce.org/release_notes/4_1_0.html

## 4.0.0 (2019-10-09)

https://guides.spreecommerce.org/release_notes/4_0_0.html

## 3.7.0 (2019-02-04)

https://guides.spreecommerce.org/release_notes/3_7_0.html

## 3.6.0 (2018-06-12)

https://guides.spreecommerce.org/release_notes/3_6_0.html

## 3.5.0 (2018-06-12)

https://guides.spreecommerce.org/release_notes/3_5_0.html

## 3.4.0 (2017-10-12)

https://guides.spreecommerce.org/release_notes/3_4_0.html

## 3.3.0 (2017-08-22)

https://guides.spreecommerce.org/release_notes/3_3_0.html

## 3.2.0 (2017-03-17)

https://guides.spreecommerce.org/release_notes/3_2_0.html

## 3.1.0 (2016-06-15)

https://guides.spreecommerce.org/release_notes/3_1_0.html

## 3.0.0 (2015-03-10)

https://guides.spreecommerce.org/release_notes/3_0_0.html

## 2.4.0 (2014-11-07)

https://guides.spreecommerce.org/release_notes/2_4_0.html
